library(testthat)
library(UtilsFaustSV)

test_check("UtilsFaustSV")
